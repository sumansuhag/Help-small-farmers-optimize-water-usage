import { useState } from 'react';
import { Scenario, CategoryType } from './types';
import { SCENARIOS, CATEGORIES } from './data/scenarios';
import { ScenarioCard } from './components/ScenarioCard';
import { ScenarioDetail } from './components/ScenarioDetail';
import { DataFlowDiagram } from './components/DataFlowDiagram';
import { Button } from './components/ui/button';
import { ShieldAlert, Network, WifiOff } from 'lucide-react';

function App() {
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('all');
  const [selectedScenario, setSelectedScenario] = useState<Scenario | null>(null);

  const filteredScenarios = selectedCategory === 'all' 
    ? SCENARIOS 
    : SCENARIOS.filter(s => s.category === selectedCategory);

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-rose-500 to-orange-600 rounded-lg flex items-center justify-center shadow-sm">
            <Network className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">ClusterDuck Protocol</h1>
            <p className="text-sm text-slate-500">Disaster Response & IoT Mesh Networks</p>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-6">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-rose-100 rounded-lg">
                  <WifiOff className="w-6 h-6 text-rose-600" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-rose-900 mb-2">Infrastructure-Independent Communication</h2>
                  <p className="text-rose-800 text-sm leading-relaxed">
                    CDP deploys ad-hoc LoRa meshes rapidly after disasters like hurricanes, earthquakes, or wildfires. 
                    It bypasses cellular outages via multi-hop relays, enabling critical updates like survivor locations 
                    and sensor alerts without any existing infrastructure.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 items-center justify-between">
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map((cat) => (
                  <Button
                    key={cat.id}
                    variant={selectedCategory === cat.id ? 'default' : 'outline'}
                    onClick={() => setSelectedCategory(cat.id as CategoryType)}
                    className={selectedCategory === cat.id ? cat.color : 'text-slate-600'}
                  >
                    {cat.label}
                  </Button>
                ))}
              </div>
              <span className="text-sm text-slate-500">
                {filteredScenarios.length} scenario{filteredScenarios.length !== 1 ? 's' : ''}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredScenarios.map((scenario) => (
                <ScenarioCard
                  key={scenario.id}
                  scenario={scenario}
                  onClick={() => setSelectedScenario(scenario)}
                />
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <DataFlowDiagram />

            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
              <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-500" />
                Why It Matters
              </h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-rose-500 mt-2 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-slate-800">Rapid Deployment</p>
                    <p className="text-xs text-slate-500">Nodes can be air-dropped or carried by hand into affected zones.</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-slate-800">Zero Infrastructure</p>
                    <p className="text-xs text-slate-500">No cell towers, power grid, or internet required to function.</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-slate-800">Low Cost</p>
                    <p className="text-xs text-slate-500">Uses accessible ESP32 hardware, making it scalable for NGOs.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      {selectedScenario && (
        <ScenarioDetail 
          scenario={selectedScenario} 
          onClose={() => setSelectedScenario(null)} 
        />
      )}
    </div>
  );
}

export default App;