import { Scenario } from '../types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { MapPin, Cpu } from 'lucide-react';

interface ScenarioCardProps {
  scenario: Scenario;
  onClick: () => void;
}

export const ScenarioCard = ({ scenario, onClick }: ScenarioCardProps) => {
  return (
    <Card 
      className="cursor-pointer hover:shadow-lg transition-all duration-200 border-slate-200 bg-white h-full"
      onClick={onClick}
    >
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="text-4xl mb-2">{scenario.icon}</div>
          <Badge variant="outline" className="text-xs">
            {scenario.category}
          </Badge>
        </div>
        <CardTitle className="text-lg">{scenario.title}</CardTitle>
        {scenario.location && (
          <CardDescription className="flex items-center gap-1 text-xs">
            <MapPin className="w-3 h-3" />
            {scenario.location}
          </CardDescription>
        )}
      </CardHeader>
      <CardContent>
        <p className="text-sm text-slate-600 line-clamp-3 mb-4">{scenario.description}</p>
        <div className="flex flex-wrap gap-1">
          {scenario.techStack.slice(0, 3).map((tech) => (
            <span key={tech} className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-full">
              {tech}
            </span>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};