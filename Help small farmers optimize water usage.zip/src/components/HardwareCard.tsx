import { Hardware, NodeType } from '../types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Wifi, Bluetooth, Zap, Cpu } from 'lucide-react';

interface HardwareCardProps {
  hardware: Hardware;
  selectedNode: NodeType | null;
  isRecommended: boolean;
}

export const HardwareCard = ({ hardware, selectedNode, isRecommended }: HardwareCardProps) => {
  const isCompatible = selectedNode ? hardware.compatibleNodes.includes(selectedNode) : true;

  return (
    <Card className={`
      transition-all duration-200 h-full
      ${!isCompatible ? 'opacity-50 grayscale' : 'hover:shadow-lg'}
      ${isRecommended && isCompatible ? 'ring-2 ring-amber-400' : ''}
    `}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg">{hardware.name}</CardTitle>
            <CardDescription className="text-sm">{hardware.manufacturer}</CardDescription>
          </div>
          {isRecommended && isCompatible && (
            <Badge className="bg-amber-500 hover:bg-amber-600">Top Pick</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-slate-600">{hardware.description}</p>
        
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-slate-700">
            <Cpu className="w-3.5 h-3.5" />
            {hardware.specs.chip}
          </div>
          <div className="flex items-center gap-1.5 text-slate-700">
            <Zap className="w-3.5 h-3.5" />
            {hardware.specs.frequency}
          </div>
          {hardware.specs.wifi && (
            <div className="flex items-center gap-1.5 text-slate-700">
              <Wifi className="w-3.5 h-3.5" />
              WiFi
            </div>
          )}
          {hardware.specs.bluetooth && (
            <div className="flex items-center gap-1.5 text-slate-700">
              <Bluetooth className="w-3.5 h-3.5" />
              Bluetooth
            </div>
          )}
        </div>

        <div className="space-y-2">
          <p className="text-xs font-semibold text-slate-500 uppercase">Key Features</p>
          <ul className="space-y-1">
            {hardware.features.slice(0, 3).map((feature, idx) => (
              <li key={idx} className="text-xs text-slate-600 flex items-start gap-2">
                <span className="text-blue-500 mt-0.5">•</span>
                {feature}
              </li>
            ))}
          </ul>
        </div>

        {!isCompatible && selectedNode && (
          <div className="p-2 bg-red-50 border border-red-200 rounded text-xs text-red-700 text-center">
            Not compatible with {selectedNode}
          </div>
        )}
      </CardContent>
    </Card>
  );
};