import { Scenario } from '../types';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { X, MapPin, Cpu, CheckCircle2 } from 'lucide-react';

interface ScenarioDetailProps {
  scenario: Scenario | null;
  onClose: () => void;
}

export const ScenarioDetail = ({ scenario, onClose }: ScenarioDetailProps) => {
  if (!scenario) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="bg-white max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <CardHeader className="border-b border-slate-200">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="text-5xl">{scenario.icon}</div>
              <div>
                <CardTitle className="text-2xl">{scenario.title}</CardTitle>
                {scenario.location && (
                  <div className="flex items-center gap-1 text-sm text-slate-500 mt-1">
                    <MapPin className="w-4 h-4" />
                    {scenario.location}
                  </div>
                )}
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          <div>
            <h3 className="font-semibold text-slate-800 mb-2">Overview</h3>
            <p className="text-slate-600 leading-relaxed">{scenario.description}</p>
          </div>

          <div>
            <h3 className="font-semibold text-slate-800 mb-3">Key Capabilities</h3>
            <ul className="space-y-2">
              {scenario.details.map((detail, idx) => (
                <li key={idx} className="flex items-start gap-2 text-sm text-slate-600">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                  {detail}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
              <Cpu className="w-4 h-4" />
              Technology Stack
            </h3>
            <div className="flex flex-wrap gap-2">
              {scenario.techStack.map((tech) => (
                <span key={tech} className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm font-medium">
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};