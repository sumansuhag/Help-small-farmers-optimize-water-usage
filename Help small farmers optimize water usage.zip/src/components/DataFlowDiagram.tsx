import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Radio, ArrowRight, Database, Cloud, Smartphone } from 'lucide-react';

export const DataFlowDiagram = () => {
  const steps = [
    {
      icon: Smartphone,
      title: 'Source',
      desc: 'Survivor texts, Sensors, GPS data',
      color: 'bg-blue-100 text-blue-600',
      borderColor: 'border-blue-300'
    },
    {
      icon: Radio,
      title: 'Mesh Relay',
      desc: 'DuckLinks & MamaDucks hop data',
      color: 'bg-emerald-100 text-emerald-600',
      borderColor: 'border-emerald-300'
    },
    {
      icon: Cloud,
      title: 'Gateway',
      desc: 'PapaDuck bridges to Cloud/Local',
      color: 'bg-purple-100 text-purple-600',
      borderColor: 'border-purple-300'
    },
    {
      icon: Database,
      title: 'Storage',
      desc: 'MQTT, Cloud DB, or Local SD Card',
      color: 'bg-amber-100 text-amber-600',
      borderColor: 'border-amber-300'
    }
  ];

  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        <CardTitle className="text-lg">How CDP Bridges the Gap</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {steps.map((step, index) => (
            <div key={step.title} className="flex flex-col items-center text-center flex-1">
              <div className={`w-16 h-16 rounded-xl ${step.color} flex items-center justify-center mb-3 border-2 ${step.borderColor}`}>
                <step.icon className="w-8 h-8" />
              </div>
              <h4 className="font-semibold text-sm text-slate-800">{step.title}</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-[120px]">{step.desc}</p>
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute right-[-50%] top-1/2 transform -translate-y-1/2 z-10">
                  <ArrowRight className="w-6 h-6 text-slate-300" />
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-200">
          <p className="text-sm text-slate-600 text-center">
            <span className="font-semibold text-slate-800">Key Advantage:</span> Data moves via multi-hop radio even when cellular towers and internet are completely down.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};