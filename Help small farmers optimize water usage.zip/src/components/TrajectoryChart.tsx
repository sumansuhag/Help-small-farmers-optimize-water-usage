import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { DataPoint } from '../types';

interface TrajectoryChartProps {
  history: DataPoint[];
}

export const TrajectoryChart = ({ history }: TrajectoryChartProps) => {
  return (
    <div className="w-full h-48 bg-white rounded-lg border border-slate-200 p-4">
      <h3 className="text-sm font-medium text-slate-700 mb-2">Angular Position Over Time</h3>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={history}>
          <XAxis 
            dataKey="time" 
            tickFormatter={(value) => value.toFixed(1)}
            stroke="#94a3b8"
          />
          <YAxis 
            tickFormatter={(value) => value.toFixed(1) + 'π'}
            domain={[-Math.PI, Math.PI]}
            stroke="#94a3b8"
          />
          <Tooltip 
            labelFormatter={(value) => `Time: ${Number(value).toFixed(2)}s`}
            formatter={(value: number) => [value.toFixed(3), '']}
            contentStyle={{ backgroundColor: 'white', border: '1px solid #e2e8f0' }}
          />
          <Line 
            type="monotone" 
            dataKey="theta1" 
            stroke="#3b82f6" 
            strokeWidth={2}
            dot={false}
            name="θ₁ (Arm 1)"
          />
          <Line 
            type="monotone" 
            dataKey="theta2" 
            stroke="#f43f5e" 
            strokeWidth={2}
            dot={false}
            name="θ₂ (Arm 2)"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};