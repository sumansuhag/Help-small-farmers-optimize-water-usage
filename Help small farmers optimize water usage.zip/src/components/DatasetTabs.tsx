import { Dataset } from '../types';
import { Button } from '../components/ui/button';
import { Plus } from 'lucide-react';

interface DatasetTabsProps {
  datasets: Dataset[];
  activeDatasetId: string;
  onSelectDataset: (id: string) => void;
  onAddDataset: () => void;
}

export const DatasetTabs = ({
  datasets,
  activeDatasetId,
  onSelectDataset,
  onAddDataset,
}: DatasetTabsProps) => {
  return (
    <div className="flex items-center gap-1 px-3 pt-3 bg-slate-100 border-b border-slate-300">
      {datasets.map((dataset) => (
        <button
          key={dataset.id}
          onClick={() => onSelectDataset(dataset.id)}
          className={`
            px-4 py-2 text-sm font-medium rounded-t-lg border-b-2 transition-colors
            ${activeDatasetId === dataset.id
              ? 'bg-white border-blue-600 text-blue-700'
              : 'bg-slate-200 border-transparent text-slate-600 hover:bg-slate-300'
            }
          `}
        >
          {dataset.name}
        </button>
      ))}
      <Button
        onClick={onAddDataset}
        size="sm"
        variant="ghost"
        className="ml-1 text-slate-500 hover:text-slate-700 hover:bg-slate-200"
      >
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );
};