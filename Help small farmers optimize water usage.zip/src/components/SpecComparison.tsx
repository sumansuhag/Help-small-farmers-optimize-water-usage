import { HARDWARE_LIST } from '../data/hardware';
import { Check, X } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

export const SpecComparison = () => {
  return (
    <Card className="border-slate-200">
      <CardHeader>
        <CardTitle className="text-lg">Hardware Comparison</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="text-left py-3 px-2 font-medium text-slate-700">Feature</th>
                {HARDWARE_LIST.map(hw => (
                  <th key={hw.id} className="text-center py-3 px-2 font-medium text-slate-700 min-w-[100px]">
                    {hw.name.split(' ').slice(0, 2).join(' ')}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-100">
                <td className="py-3 px-2 text-slate-600">Chip</td>
                {HARDWARE_LIST.map(hw => (
                  <td key={hw.id} className="py-3 px-2 text-center text-slate-800">{hw.specs.chip}</td>
                ))}
              </tr>
              <tr className="border-b border-slate-100 bg-slate-50/50">
                <td className="py-3 px-2 text-slate-600">WiFi</td>
                {HARDWARE_LIST.map(hw => (
                  <td key={hw.id} className="py-3 px-2 text-center">
                    {hw.specs.wifi ? <Check className="w-4 h-4 mx-auto text-green-600" /> : <X className="w-4 h-4 mx-auto text-slate-400" />}
                  </td>
                ))}
              </tr>
              <tr className="border-b border-slate-100">
                <td className="py-3 px-2 text-slate-600">Bluetooth</td>
                {HARDWARE_LIST.map(hw => (
                  <td key={hw.id} className="py-3 px-2 text-center">
                    {hw.specs.bluetooth ? <Check className="w-4 h-4 mx-auto text-green-600" /> : <X className="w-4 h-4 mx-auto text-slate-400" />}
                  </td>
                ))}
              </tr>
              <tr className="border-b border-slate-100 bg-slate-50/50">
                <td className="py-3 px-2 text-slate-600">CDP Support</td>
                {HARDWARE_LIST.map(hw => (
                  <td key={hw.id} className="py-3 px-2 text-center">
                    <Check className="w-4 h-4 mx-auto text-green-600" />
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-2 text-slate-600">Best For</td>
                {HARDWARE_LIST.map(hw => (
                  <td key={hw.id} className="py-3 px-2 text-center text-xs text-slate-600">
                    {hw.bestFor.join(', ')}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};