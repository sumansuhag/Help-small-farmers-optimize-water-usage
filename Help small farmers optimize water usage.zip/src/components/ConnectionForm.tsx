import { useState } from 'react';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Button } from '../components/ui/button';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Copy, Check } from 'lucide-react';

export const ConnectionForm = () => {
  const [copied, setCopied] = useState(false);
  const [config, setConfig] = useState({
    server: 'your-server.com',
    port: '446',
    database: 'your-database',
    driver: 'microsoft',
    authentication: 'basic',
    encryption: false,
  });

  const generateConnectionString = () => {
    return `Server=${config.server}:${config.port};Database=${config.database};Driver=${config.driver === 'microsoft' ? 'Microsoft .NET Framework' : 'IBM ODBC'};Authentication=${config.authentication};`;
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(generateConnectionString());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-lg border border-slate-300 p-6">
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Connection Configuration</h3>
      
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="server" className="text-slate-700">Server Address</Label>
            <Input
              id="server"
              value={config.server}
              onChange={(e) => setConfig({ ...config, server: e.target.value })}
              placeholder="server:port"
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="port" className="text-slate-700">Port</Label>
            <Input
              id="port"
              value={config.port}
              onChange={(e) => setConfig({ ...config, port: e.target.value })}
              placeholder="446"
              className="mt-1"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="database" className="text-slate-700">Database Name</Label>
          <Input
            id="database"
            value={config.database}
            onChange={(e) => setConfig({ ...config, database: e.target.value })}
            placeholder="Your database name"
            className="mt-1"
          />
        </div>

        <div>
          <Label className="text-slate-700">Driver Selection</Label>
          <RadioGroup
            value={config.driver}
            onValueChange={(value) => setConfig({ ...config, driver: value as 'microsoft' | 'ibm' })}
            className="mt-2"
          >
            <div className="flex items-center space-x-2 p-3 rounded-lg border-2 border-green-300 bg-green-50">
              <RadioGroupItem value="microsoft" id="microsoft" />
              <Label htmlFor="microsoft" className="cursor-pointer flex-1">
                <span className="font-medium text-green-800">Microsoft .NET Framework (Recommended)</span>
                <p className="text-sm text-green-700">Enables DirectQuery, avoids licensing errors</p>
              </Label>
            </div>
            <div className="flex items-center space-x-2 p-3 rounded-lg border-2 border-red-200 bg-red-50 opacity-60">
              <RadioGroupItem value="ibm" id="ibm" />
              <Label htmlFor="ibm" className="cursor-pointer flex-1">
                <span className="font-medium text-red-800">IBM ODBC Driver</span>
                <p className="text-sm text-red-700">Forces Import mode, not recommended</p>
              </Label>
            </div>
          </RadioGroup>
        </div>

        <div>
          <Label className="text-slate-700">Authentication</Label>
          <RadioGroup
            value={config.authentication}
            onValueChange={(value) => setConfig({ ...config, authentication: value })}
            className="mt-2"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="basic" id="basic" />
              <Label htmlFor="basic" className="cursor-pointer">Basic (IBM i credentials)</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="windows" id="windows" />
              <Label htmlFor="windows" className="cursor-pointer">Windows Authentication</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="encryption"
            checked={config.encryption}
            onChange={(e) => setConfig({ ...config, encryption: e.target.checked })}
            className="w-4 h-4 text-blue-600 rounded"
          />
          <Label htmlFor="encryption" className="cursor-pointer">Enable SSL Encryption</Label>
        </div>
      </div>

      <div className="mt-6 p-4 bg-slate-100 rounded-lg border border-slate-200">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-slate-700">Connection String Preview</span>
          <Button
            onClick={handleCopy}
            size="sm"
            variant="ghost"
            className="text-slate-600 hover:text-slate-800"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 mr-1" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 mr-1" />
                Copy
              </>
            )}
          </Button>
        </div>
        <code className="text-sm text-slate-600 font-mono break-all">
          {generateConnectionString()}
        </code>
      </div>
    </div>
  );
};