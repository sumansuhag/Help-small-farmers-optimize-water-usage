import { CheckCircle2 } from 'lucide-react';

interface ProgressBarProps {
  progress: number;
  total: number;
  completed: number;
}

export const ProgressBar = ({ progress, total, completed }: ProgressBarProps) => {
  return (
    <div className="bg-white rounded-lg border border-slate-300 p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-slate-800">Setup Progress</h3>
          <p className="text-sm text-slate-500">{completed} of {total} steps completed</p>
        </div>
        <div className={`p-3 rounded-full ${progress === 100 ? 'bg-green-100' : 'bg-blue-100'}`}>
          <CheckCircle2 className={`w-8 h-8 ${progress === 100 ? 'text-green-600' : 'text-blue-600'}`} />
        </div>
      </div>
      
      <div className="relative h-4 bg-slate-200 rounded-full overflow-hidden">
        <div
          className={`
            absolute top-0 left-0 h-full rounded-full transition-all duration-500 ease-out
            ${progress === 100 ? 'bg-green-500' : 'bg-blue-500'}
          `}
          style={{ width: `${progress}%` }}
        />
      </div>
      
      <div className="mt-3 text-center">
        <span className={`text-2xl font-bold ${progress === 100 ? 'text-green-600' : 'text-blue-600'}`}>
          {progress}%
        </span>
        <span className="text-sm text-slate-500 ml-2">Complete</span>
      </div>
      
      {progress === 100 && (
        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-sm text-green-700 font-medium text-center">
            🎉 All steps completed! Your Db2 DirectQuery connection should be ready.
          </p>
        </div>
      )}
    </div>
  );
};