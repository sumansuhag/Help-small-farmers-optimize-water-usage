import { Dataset } from '../types';
import { Button } from '../components/ui/button';
import { Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface SyntaxPreviewProps {
  dataset: Dataset;
}

export const SyntaxPreview = ({ dataset }: SyntaxPreviewProps) => {
  const [copied, setCopied] = useState(false);

  const generateSyntax = () => {
    const varList = dataset.columns
      .map(col => {
        const sampleValue = dataset.rows[0]?.cells[dataset.columns.indexOf(col)]?.value || '';
        const type = isNaN(Number(sampleValue)) || sampleValue === '' ? 'A10' : 'F8.0';
        return `${col} (${type})`;
      })
      .join(' ');

    const dataLines = dataset.rows
      .map(row => row.cells.map(cell => cell.value || '.').join(' '))
      .filter(line => line.trim() !== '...')
      .join('\n');

    return `DATA LIST LIST /${varList}.
BEGIN DATA.
${dataLines}
END DATA.
EXECUTE.`;
  };

  const handleCopy = async () => {
    const syntax = generateSyntax();
    await navigator.clipboard.writeText(syntax);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const syntax = generateSyntax();

  return (
    <div className="mt-4 border border-slate-300 rounded-lg overflow-hidden bg-slate-900">
      <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
        <span className="text-sm font-medium text-slate-300">SPSS Syntax</span>
        <Button
          onClick={handleCopy}
          size="sm"
          variant="ghost"
          className="text-slate-300 hover:text-white hover:bg-slate-700"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 mr-1" />
              Copied!
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 mr-1" />
              Copy Syntax
            </>
          )}
        </Button>
      </div>
      <pre className="p-4 text-sm text-green-400 font-mono overflow-x-auto whitespace-pre-wrap">
        {syntax}
      </pre>
    </div>
  );
};