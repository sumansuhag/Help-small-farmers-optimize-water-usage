import { NodeType, NODE_INFO } from '../types';
import { cn } from '../utils/cn'; // Assuming utility exists or using inline class logic

interface TopologyDiagramProps {
  selectedNode: NodeType | null;
  onNodeSelect: (node: NodeType) => void;
}

export const TopologyDiagram = ({ selectedNode, onNodeSelect }: TopologyDiagramProps) => {
  const nodes: NodeType[] = ['papaduck', 'mamaduck', 'ducklink'];

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6">
      <h3 className="text-lg font-semibold text-slate-800 mb-6 text-center">Network Topology</h3>
      
      <div className="flex flex-col items-center gap-8">
        {nodes.map((nodeType, index) => {
          const info = NODE_INFO[nodeType];
          const isSelected = selectedNode === nodeType;
          
          return (
            <div key={nodeType} className="flex flex-col items-center w-full max-w-md">
              <button
                onClick={() => onNodeSelect(nodeType)}
                className={`
                  relative w-full p-4 rounded-xl border-2 transition-all duration-200 text-left
                  ${isSelected 
                    ? 'border-blue-500 bg-blue-50 shadow-md' 
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                  }
                `}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-lg ${info.color} flex items-center justify-center text-2xl shadow-sm`}>
                    {info.icon}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-slate-800">{info.title}</h4>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{info.description}</p>
                  </div>
                  {isSelected && (
                    <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full" />
                    </div>
                  )}
                </div>
              </button>

              {index < nodes.length - 1 && (
                <div className="h-8 w-0.5 bg-slate-300 my-1 relative">
                  <div className="absolute inset-0 bg-gradient-to-b from-slate-300 to-transparent" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-8 p-4 bg-slate-50 rounded-lg border border-slate-200">
        <p className="text-sm text-slate-600 text-center">
          <span className="font-medium">Tip:</span> Click a node type to filter compatible hardware recommendations below.
        </p>
      </div>
    </div>
  );
};