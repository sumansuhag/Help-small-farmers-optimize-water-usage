import { ClipboardData, Cell } from '../types';

const CLIPBOARD_KEY = 'data-clipboard-copied';

export const copyToClipboard = (cells: Cell[][]): void => {
  const data: ClipboardData = {
    cells,
    timestamp: Date.now(),
  };
  localStorage.setItem(CLIPBOARD_KEY, JSON.stringify(data));
  
  // Also copy as TSV for external pasting
  const tsv = cells.map(row => row.map(cell => cell.value).join('\t')).join('\n');
  navigator.clipboard.writeText(tsv);
};

export const getFromClipboard = (): ClipboardData | null => {
  const stored = localStorage.getItem(CLIPBOARD_KEY);
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch {
    return null;
  }
};

export const parseTSV = (text: string): Cell[][] => {
  const lines = text.trim().split('\n');
  return lines.map(line => {
    const values = line.split('\t');
    return values.map(val => {
      const trimmed = val.trim();
      const type = isNaN(Number(trimmed)) || trimmed === '' ? 'string' : 'number';
      return { value: trimmed, type };
    });
  });
};

export const hasClipboardData = (): boolean => {
  return localStorage.getItem(CLIPBOARD_KEY) !== null;
};