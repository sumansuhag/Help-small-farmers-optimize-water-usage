export interface Scenario {
  id: string;
  title: string;
  category: 'disaster' | 'environmental' | 'events' | 'agriculture';
  icon: string;
  description: string;
  details: string[];
  location?: string;
  techStack: string[];
}

export type CategoryType = 'all' | 'disaster' | 'environmental' | 'events' | 'agriculture';