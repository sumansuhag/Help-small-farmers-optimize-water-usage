import { Hardware } from '../types';

export const HARDWARE_LIST: Hardware[] = [
  {
    id: 'heltec-v3',
    name: 'Heltec WiFi LoRa 32 V3',
    manufacturer: 'Heltec',
    features: [
      'ESP32-S3 chip',
      'Native CDP Firmware Support',
      'Built-in WiFi & Bluetooth',
      'OLED Display',
      'High sensitivity'
    ],
    compatibleNodes: ['ducklink', 'mamaduck', 'papaduck'],
    bestFor: ['papaduck'],
    description: 'The top recommendation for all node types. The V3 with ESP32-S3 offers superior performance and native CDP compatibility via PlatformIO.',
    specs: {
      chip: 'ESP32-S3',
      frequency: '915 MHz (regional)',
      wifi: true,
      bluetooth: true,
    },
  },
  {
    id: 'heltec-v2',
    name: 'Heltec LoRa 32 V2',
    manufacturer: 'Heltec',
    features: [
      'ESP32 chip',
      'Native CDP Firmware Support',
      'Built-in WiFi & Bluetooth',
      'OLED Display',
      'Proven stability'
    ],
    compatibleNodes: ['ducklink', 'mamaduck', 'papaduck'],
    bestFor: ['mamaduck', 'ducklink'],
    description: 'A reliable workhorse for the ClusterDuck Protocol. Excellent for MamaDucks and DuckLinks where the latest S3 features are not critical.',
    specs: {
      chip: 'ESP32',
      frequency: '915 MHz (regional)',
      wifi: true,
      bluetooth: true,
    },
  },
  {
    id: 'ttgo-tbeam',
    name: 'TTGO T-Beam ESP32',
    manufacturer: 'TTGO',
    features: [
      'ESP32 chip',
      'Integrated GPS',
      'Built-in WiFi',
      'LoRa @ 915 MHz',
      'Low power consumption'
    ],
    compatibleNodes: ['ducklink', 'mamaduck', 'papaduck'],
    bestFor: ['papaduck', 'mamaduck'],
    description: 'A versatile option supporting Wi-Fi for gateways. The integrated GPS makes it excellent for mobile PapaDucks or tracking assets.',
    specs: {
      chip: 'ESP32',
      frequency: '915 MHz',
      wifi: true,
      bluetooth: true,
    },
  },
  {
    id: 'cubecell',
    name: 'CubeCell Dev Board',
    manufacturer: 'Heltec',
    features: [
      'ASR6501/ASR6502',
      'Ultra-low power',
      'Two-way mesh support',
      'RadioLib compatible',
      'Compact form factor'
    ],
    compatibleNodes: ['ducklink', 'mamaduck'],
    bestFor: ['ducklink'],
    description: 'Designed specifically for long-battery-life IoT applications. Ideal for remote DuckLinks that need to operate for months on a single charge.',
    specs: {
      chip: 'ASR6501',
      frequency: '915 MHz',
      wifi: false,
      bluetooth: false,
    },
  },
];