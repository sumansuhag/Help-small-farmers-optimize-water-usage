import { Scenario } from '../types';

export const SCENARIOS: Scenario[] = [
  {
    id: 'hurricane-maria',
    title: 'Hurricane Maria Response',
    category: 'disaster',
    icon: '🌀',
    description: 'Rapid deployment of ad-hoc LoRa meshes to restore communications when cellular infrastructure fails completely.',
    details: [
      'Survivor location tracking via GPS-enabled nodes',
      'Critical medical supply requests',
      'Text messaging without cell towers',
      'Bypasses weeks-long infrastructure repair times'
    ],
    location: 'Puerto Rico',
    techStack: ['LoRa Mesh', 'GPS', 'Offline Storage']
  },
  {
    id: 'himalayan-rescue',
    title: 'Himalayan Earthquake',
    category: 'disaster',
    icon: '⛰️',
    description: 'Planned deployment for remote mountain regions where terrain blocks traditional signals and roads are impassable.',
    details: [
      'Multi-hop relays across difficult terrain',
      'Avalanche sensor integration',
      'Low-power operation for extended battery life',
      'Connects remote villages to relief coordination'
    ],
    location: 'India Himalayas',
    techStack: ['Long-range LoRa', 'Solar Power', 'Mesh Relay']
  },
  {
    id: 'wildfire-tracking',
    title: 'Wildfire Monitoring',
    category: 'environmental',
    icon: '🔥',
    description: 'Environmental sensors detecting temperature spikes and smoke in real-time across vast forest areas.',
    details: [
      'Early warning system for fire crews',
      'Perimeter tracking via moving nodes',
      'Data aggregation via PapaDuck gateways',
      'Functions in smoke-obscured visibility'
    ],
    techStack: ['Temp Sensors', 'MQTT Bridge', 'Cloud Analytics']
  },
  {
    id: 'crowded-events',
    title: 'Mass Event Congestion',
    category: 'events',
    icon: '🎉',
    description: 'Alleviating network congestion at concerts or festivals where cellular networks become overloaded.',
    details: [
      'Local emergency broadcasting',
      'Crowd density mapping',
      'Lost and found coordination',
      'Works independent of carrier load'
    ],
    techStack: ['Local Mesh', 'Bluetooth', 'High Density']
  },
  {
    id: 'agriculture',
    title: 'Smart Agriculture',
    category: 'agriculture',
    icon: '🌾',
    description: 'Soil moisture and crop health monitoring across large farms without expensive cellular data plans.',
    details: [
      'Soil moisture tracking',
      'Livestock location monitoring',
      'Irrigation system automation',
      'Cost-effective for remote fields'
    ],
    techStack: ['Soil Sensors', 'Solar Nodes', 'Long Range']
  },
  {
    id: 'wildlife',
    title: 'Wildlife Tracking',
    category: 'environmental',
    icon: '🦌',
    description: 'Tracking animal migration patterns and poaching alerts in protected reserves without grid power.',
    details: [
      'GPS collar data relay',
      'Poacher intrusion alerts',
      'Minimal impact on animal behavior',
      'Solar-powered relay stations'
    ],
    techStack: ['GPS Collars', 'Solar Relay', 'Low Power']
  }
];

export const CATEGORIES = [
  { id: 'all', label: 'All Scenarios', color: 'bg-slate-600' },
  { id: 'disaster', label: 'Disaster Response', color: 'bg-rose-500' },
  { id: 'environmental', label: 'Environmental', color: 'bg-emerald-500' },
  { id: 'events', label: 'Public Events', color: 'bg-blue-500' },
  { id: 'agriculture', label: 'Agriculture', color: 'bg-amber-500' },
];